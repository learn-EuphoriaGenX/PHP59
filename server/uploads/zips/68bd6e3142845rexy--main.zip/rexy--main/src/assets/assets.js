/**
 * @copyright 2025 Aniket Chakraborty
 */

import banner from './banner.webp';
import iconLogo from './logo-icon.svg';
import logoDark from './logo-dark.svg';
import logoLight from './logo-light.svg';


export {
    banner,
    iconLogo,
    logoDark,
    logoLight,
    };