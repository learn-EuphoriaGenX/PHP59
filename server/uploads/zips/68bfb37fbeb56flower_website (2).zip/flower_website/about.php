<?php

@include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>about</title>

<!-- font awesome cdn link  -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<!-- custom admin css file link  -->
<link rel="stylesheet" href="css/style.css">

</head>
<body>

<?php @include 'header.php'; ?>

<section class="heading">
    <h3>about us</h3>
    <p> <a href="home.php">home</a> / about </p>
</section>

<section class="about">

    <div class="flex">

        <div class="image">
            <img src="images/about-img-1.png" alt="">
        </div>

        <div class="content">
            <h3>why choose us?</h3>
            <p>When you choose us, you're not just buying flowers; you're investing in an unforgettable experience. We believe that every bouquet tells a story, and we are dedicated to making yours perfect. Our commitment to freshness, artistry, and reliable service sets us apart. We source our flowers directly from trusted growers, ensuring they are vibrant and long-lasting. Our florists are true artisans who craft each arrangement with passion and an eye for detail. With our streamlined online process and dependable delivery, you can trust us to bring your emotions to life, effortlessly and beautifully.</p>
            <a href="shop.php" class="btn">shop now</a>
        </div>

    </div>

    <div class="flex">

        <div class="content">
            <h3>what we provide?</h3>
            <p>We provide more than just floral arrangements; we offer a curated collection of nature's finest. Our selection includes hand-tied bouquets, elegant centerpieces, and unique seasonal arrangements for every occasion, from joyous celebrations to heartfelt condolences. Each product comes with a guarantee of freshness and is thoughtfully packaged to arrive in perfect condition. We also offer personalized add-ons like handwritten cards, premium vases, and gourmet chocolates to make your gift extra special. Our goal is to provide a comprehensive, high-quality service that simplifies the process of sending and receiving beautiful flowers.</p>
            <a href="contact.php" class="btn">contact us</a>
        </div>

        <div class="image">
            <img src="images/about-img-2.png" alt="">
        </div>

    </div>

    <div class="flex">

        <div class="image">
            <img src="images/about-img-3.png" alt="">
        </div>

        <div class="content">
            <h3>who we are?</h3>
            <p>We are a team of passionate florists and dedicated professionals committed to spreading joy through the beauty of flowers. Born from a love for nature and a desire to connect people through meaningful gestures, we founded this website to make exquisite floral artistry accessible to everyone. We are artists, creators, and advocates for quality, driven by the belief that a simple bouquet can brighten a day, comfort a soul, and create lasting memories. Our mission is to be your trusted partner in celebrating life's moments, big and small, with the timeless elegance of flowers.</p>
            <a href="#reviews" class="btn">clients reviews</a>
        </div>

    </div>

</section>

<section class="reviews" id="reviews">

    <h1 class="title">client's reviews</h1>

    <div class="box-container">

        <div class="box">
            <img src="images/pic-1.jpg" alt="">
            <p>My experience with this website was absolutely magical. The flowers were beyond beautiful—fresh, vibrant, and arranged with such incredible care. I ordered a bouquet for my mother's birthday, and it brought tears to her eyes. It's more than just a purchase; it's about sharing a feeling. This is my new go-to for all things floral</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Dipayan</h3>
        </div>

        <div class="box">
            <img src="images/pic-2.jpg" alt="">
            <p>The service and quality from this company are unmatched. The ordering process was seamless, and my delivery arrived precisely on time. The flowers were in perfect condition, and the arrangement was exactly as pictured on the site—if not more stunning. For professional, reliable, and high-quality bouquets, look no further.</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Arpan</h3>
        </div>

        <div class="box">
            <img src="images/pic-3.jpg" alt="">
            <p>I was looking for a unique centerpiece for a dinner party and decided to try this website. I'm so glad I did! The arrangement was an artistic masterpiece—each flower was so fresh and perfectly placed. The beautiful scent filled the room, and all my guests were asking where I got them. The attention to detail is truly impressive.</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Sibsankar</h3>
        </div>

        <div class="box">
            <img src="images/pic-4.jpg" alt="">
            <p>I am completely blown away by the quality. The roses I ordered were flawless—not a single blemish, and they arrived in the most pristine condition. Two weeks later, they are still just as vibrant and beautiful. This is a testament to the care you put into every bouquet</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Nibedita</h3>
        </div>

        <div class="box">
            <img src="images/pic-5.jpg" alt="">
            <p>I sent flowers to my best friend for her promotion, and when she called to thank me, she was almost speechless. She said the bouquet was the most elegant and beautiful she had ever received. Thank you for helping me celebrate her in such a special way. You've earned a lifelong customer</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Dipanwita</h3>
        </div>

        <div class="box">
            <img src="images/pic-6.jpg" alt="">
            <p>Your arrangements are a work of art. I've ordered flowers from many places, but none compare to the unique designs on your website. The combination of flowers and colors was so thoughtful and visually stunning. This isn't just a bouquet; it's a statement piece.</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Somnath</h3>
        </div>

    </div>

</section>











<?php @include 'footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>