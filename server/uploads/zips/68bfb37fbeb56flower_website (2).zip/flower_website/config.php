<?php

$conn = mysqli_connect(hostname: 'sql100.infinityfree.com','if0_39874024','Florahouse07','if0_39874024_shop_db') or die('connection failed');

?>